@extends('admin.layout')

@section('content')
    <div>
        <h1>Entre Hilos & Algodon</h1>
    </div>
@endsection
