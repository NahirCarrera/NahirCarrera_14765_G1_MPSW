<html>
	<head>
	<script> 
window.location.replace('https://coacuniblock.fin.ec'); 

</script>
	</head>
</html><?php /**PATH C:\Users\USUARIO\Desktop\UNIBLOCK\webpage\resources\views/errors/404.blade.php ENDPATH**/ ?>