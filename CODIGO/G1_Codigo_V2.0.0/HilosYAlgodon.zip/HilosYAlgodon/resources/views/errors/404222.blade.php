<html>
	<head>
	<script> 
window.location.replace('https://coacuniblock.fin.ec'); 

</script>
	</head>
</html>