<?php echo e($slot); ?>

<?php /**PATH C:\Users\crist\Desktop\Uni\HostProyectos\PROCESOS\webpageModificandoVistasDeProductos\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>