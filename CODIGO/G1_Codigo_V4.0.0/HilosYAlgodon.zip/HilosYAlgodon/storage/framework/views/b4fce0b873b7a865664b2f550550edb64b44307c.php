

<?php $__env->startSection('content'); ?>
    <div>
        <h1>Buen día :D</h1>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\crist\Desktop\Uni\HostProyectos\PROCESOS\HilosYAlgodon\resources\views/admin/adminPrincipal.blade.php ENDPATH**/ ?>