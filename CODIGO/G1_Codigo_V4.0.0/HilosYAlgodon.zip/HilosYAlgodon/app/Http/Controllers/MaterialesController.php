<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MaterialesController extends Controller
{
    public function index(){
        return 'xd';
    }
}
