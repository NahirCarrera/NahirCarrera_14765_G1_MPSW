@extends('admin.layout')

@section('content')
    <div>
        <h1>Buen día :D</h1>
    </div>
@endsection
